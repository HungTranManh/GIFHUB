package com.t3h.calculatoraidl;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.databinding.DataBindingUtil;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.t3h.calculatoraidl.databinding.ActivityMainBinding;
import com.t3h.calculatoraidlservice.ICalculator;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ActivityMainBinding binding;
    private ServiceConnection conn;
    private ICalculator cal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,
                R.layout.activity_main);
        initViews();

        //tao ket noi voi service
        initConnect();
    }

    private void initConnect() {
        conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                //ket noi thanh cong
                cal =
                        ICalculator.Stub
                                .asInterface(iBinder);

            }

            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                cal = null;
            }
        };

        Intent intent = new Intent();
        //par1: packageName cua project chua service
        //par2:package(chua service) +ten class Service
        intent.setClassName(
                "com.t3h.calculatoraidlservice",
                "com.t3h.calculatoraidlservice.ServiceCalculator");
        bindService(intent, conn, BIND_AUTO_CREATE);

    }

    private void initViews() {
        binding.btnSub.setOnClickListener(this);
        binding.btnSum.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String textNumberA = binding.edtNumberA.getText().toString();
        String textNumberB = binding.edtNumberB.getText().toString();
        float numberA = Float.parseFloat(textNumberA);
        float numberB = Float.parseFloat(textNumberB);
        switch (v.getId()) {
            case R.id.btn_sub:
                if (cal == null ) {
                    return;
                }
                try {
                    float result =
                            cal.sub(numberA, numberB);
                    binding.tvResult.setText(result+"");
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                break;
            case R.id.btn_sum:
                if (cal == null ) {
                    return;
                }
                try {
                    float result =
                            cal.sum(numberA, numberB);
                    binding.tvResult.setText(result+"");
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        unbindService(conn);
        super.onDestroy();
    }
}
