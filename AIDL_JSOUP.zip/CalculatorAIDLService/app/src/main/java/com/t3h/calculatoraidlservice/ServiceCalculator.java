package com.t3h.calculatoraidlservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;

/**
 * Created by ducnd on 5/13/18.
 */

public class ServiceCalculator extends Service {

    private ICalculator.Stub cal;

    @Override
    public void onCreate() {
        super.onCreate();
        //tao ra ICalculator.Stub ( giong interface)
        //de trao doi du lieu voi ben ket noi
        cal =
                new ICalculator.Stub() {
                    @Override
                    public float sum(float numberA, float numberB) throws RemoteException {
                        return numberA+numberB;
                    }

                    @Override
                    public float sub(float numberA, float numberB) throws RemoteException {
                        return numberA-numberB;
                    }

                    @Override
                    public boolean charge(String username, String password, float amount, String productCod) throws RemoteException {
                        return false;
                    }
                };
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        //tra ve interface de calculator
        return cal.asBinder();
    }


}
