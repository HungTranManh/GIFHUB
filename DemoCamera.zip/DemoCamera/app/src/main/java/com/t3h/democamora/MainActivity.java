package com.t3h.democamora;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (checkPermissionCamera()) {
            //bat camera
            openCamera();
        }
    }


    private boolean checkPermissionCamera() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        List<String> permissions = new ArrayList<>();
        boolean result = true;
        boolean isShould = true;
        int permissionWriteStore = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permissionWriteStore !=
                PackageManager.PERMISSION_GRANTED) {
            result = false;
            if (ShareUtils.getNumberRequestPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0) {
                //lan dau
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            } else {
                if (ActivityCompat
                        .shouldShowRequestPermissionRationale(this,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                } else {
                    isShould = false;
                }
            }

        }
        int permissionReadStore = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permissionReadStore !=
                PackageManager.PERMISSION_GRANTED) {
            result = false;
            if (ShareUtils.getNumberRequestPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) == 0) {
                //lan dau
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            } else {
                if (ActivityCompat
                        .shouldShowRequestPermissionRationale(this,
                                Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                } else {
                    isShould = false;
                }
            }
        }

        int permissionCamera = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA);

        if (permissionCamera !=
                PackageManager.PERMISSION_GRANTED) {
            if (ShareUtils.getNumberRequestPermission(this,
                    Manifest.permission.CAMERA) == 0) {
                //lan dau
                permissions.add(Manifest.permission.CAMERA);
            } else {
                if (ActivityCompat
                        .shouldShowRequestPermissionRationale(this,
                                Manifest.permission.CAMERA)) {
                    permissions.add(Manifest.permission.CAMERA);
                } else {
                    isShould = false;
                }
            }
        }

        if (!result && isShould) {
            ActivityCompat.requestPermissions(this,
                    permissions.toArray(new String[permissions.size()]),
                    100);
        } else {
            if (!isShould) {
                //mo setting
                showPopupSetting();
            }
        }

        return result;
    }

    private void showPopupSetting() {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 99);
            }
        });
        builder.setTitle("Permission");
        builder.setMessage("Open setting to grant permission?");
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ( requestCode == 99) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_GRANTED
                    ){
                openCamera();
            }
        }
    }

    private void openCamera(){
        Toast.makeText(this, "Open Camera", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for (int i = 0; i < permissions.length; i++) {
            int numberPermission = ShareUtils.getNumberRequestPermission(this, permissions[i]);
            ShareUtils.savePermission(this,
                    permissions[i],
                    numberPermission + 1);

        }
        boolean isGrandAll = true;
        for (int grantResult : grantResults) {
            if (grantResult != PackageManager.PERMISSION_GRANTED) {
                isGrandAll = false;
                //save lai


            }
        }
        if ( isGrandAll ) {
            //open camera
            openCamera();
        }

    }
}
