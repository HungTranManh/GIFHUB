package com.t3h.democamora;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by ducnd on 5/13/18.
 */

public class ShareUtils {
    private static final String SHARE_NAME = "SHARE_NAME";
    public static void savePermission(Context context, String permission,
                                int numberRequestPermission) {
        SharedPreferences share =
                context.getSharedPreferences(SHARE_NAME, Context.MODE_PRIVATE);
        share.edit().putInt(permission,
                numberRequestPermission).apply();
    }

    public static int getNumberRequestPermission(Context context,
                                                 String permission) {
        return context.getSharedPreferences(SHARE_NAME, Context.MODE_PRIVATE)
                .getInt(permission, 0);
    }

}
